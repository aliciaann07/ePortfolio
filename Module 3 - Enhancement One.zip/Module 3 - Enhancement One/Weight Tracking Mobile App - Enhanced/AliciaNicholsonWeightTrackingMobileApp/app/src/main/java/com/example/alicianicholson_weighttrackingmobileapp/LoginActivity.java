package com.example.alicianicholson_weighttrackingmobileapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// LoginActivity handles user login and account creation
public class LoginActivity extends AppCompatActivity {

    // Database helper instance
    private DatabaseHelper dbHelper;

    // Stores current logged in user id
    private int currentUserId = -1;

    // Username input field
    private EditText usernameInput;

    // Password input field
    private EditText passwordInput;

    // Login button
    private Button loginButton;

    // Create account button
    private Button createAccountButton;

    // Runs when activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge to edge display
        EdgeToEdge.enable(this);

        // Sets layout for login screen
        setContentView(R.layout.activity_login);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Connect username input
        usernameInput = findViewById(R.id.etUsername);

        // Connect password input
        passwordInput = findViewById(R.id.etPassword);

        // Connect login button
        loginButton = findViewById(R.id.btnLogin);

        // Connect create account button
        createAccountButton = findViewById(R.id.btnCreateAccount);

        // Handles login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        // Handles create account button click
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCreateAccount();
            }
        });

        // Handles system bar padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            // Gets system bar insets
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Applies padding to layout
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Logs in an existing user
    private void handleLogin() {

        // Get username text
        String username = usernameInput.getText().toString().trim();

        // Get password text
        String password = passwordInput.getText().toString().trim();

        // Checks for empty fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate login for existing user
        int userId = dbHelper.getUserId(username, password);

        // Check for invalid login
        if (userId == -1) {
            Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            return;
        }

        // Store logged in user id
        currentUserId = userId;

        // Go to next screen
        goToWeightScreen();
    }

    // Create new user account
    private void handleCreateAccount() {

        // Get username text
        String username = usernameInput.getText().toString().trim();

        // Get password text
        String password = passwordInput.getText().toString().trim();

        // Checks for empty fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if username already exists
        if (dbHelper.usernameExists(username)) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create new user account
        long newUserId = dbHelper.createUser(username, password);

        // Check if account creation failed
        if (newUserId == -1) {
            Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show();
            return;
        }

        // Store logged in user id
        currentUserId = (int) newUserId;

        Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();

        // Go to next screen
        goToWeightScreen();
    }

    // Opens weight screen activity
    private void goToWeightScreen() {

        // Create intent for next screen
        Intent intent = new Intent(LoginActivity.this, WeightHistoryActivity.class);

        // Pass user id to next screen
        intent.putExtra("USER_ID", currentUserId);

        startActivity(intent);
        finish();
    }
}