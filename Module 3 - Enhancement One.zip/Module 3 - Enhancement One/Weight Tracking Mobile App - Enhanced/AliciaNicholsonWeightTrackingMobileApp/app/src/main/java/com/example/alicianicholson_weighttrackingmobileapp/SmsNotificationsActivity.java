package com.example.alicianicholson_weighttrackingmobileapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// SMS Notifications Activity manages SMS alert settings and goal weight configuration
public class SmsNotificationsActivity extends AppCompatActivity {

    // Database helper instance
    private DatabaseHelper dbHelper;

    // Current logged in user id
    private int currentUserId = -1;

    // Phone number and goal weight input fields
    private EditText phoneInput;
    private EditText goalWeightInput;

    // Enable SMS button
    private Button enableSmsButton;

    // Test SMS button
    private Button testSmsButton;

    // Status text view
    private TextView smsStatusText;

    // Request code for SMS permission
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    // Stores whether SMS is enabled for user
    private boolean smsEnabled = false;


    // Runs when activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge to edge display
        EdgeToEdge.enable(this);

        // Sets layout for SMS notifications screen
        setContentView(R.layout.activity_sms_notifications);

        // Handles system bar padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            // Gets system bar insets
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Applies padding to layout
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user id from previous activity
        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        // Check for missing user id
        if (currentUserId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Connect phone input
        phoneInput = findViewById(R.id.etPhoneNumber);

        // Connect goal weight input
        goalWeightInput = findViewById(R.id.etGoalWeight);

        // Connect enable button
        enableSmsButton = findViewById(R.id.btnEnableSms);

        // Connect test button
        testSmsButton = findViewById(R.id.btnTestSms);

        // Connect status text
        smsStatusText = findViewById(R.id.tvSmsStatus);

        // Disable test button until SMS is enabled
        testSmsButton.setEnabled(false);

        // Set default status text
        smsStatusText.setText("Status: Not Enabled");

        // Load saved SMS settings
        loadSmsSettings();

        // Handles enable SMS button click
        enableSmsButton.setOnClickListener(v -> handleEnableSmsClick());

        // Handles test SMS button click
        testSmsButton.setOnClickListener(v -> sendTestSms());
    }

    // Handles permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == SMS_PERMISSION_REQUEST_CODE) {

            // Check if permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                smsStatusText.setText("Status: Permission Granted");
                Toast.makeText(this, "Permission granted. Tap Enable again to turn on SMS.", Toast.LENGTH_SHORT).show();
            }
            else {
                smsStatusText.setText("Status: Permission Denied");
                Toast.makeText(this, "Permission denied. App will still work without SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Loads SMS settings from database and updates screen
    private void loadSmsSettings() {

        // Get settings from database
        Cursor cursor = dbHelper.getSmsSettings(currentUserId);

        // Load settings if they exist
        if (cursor.moveToFirst()) {
            int enabledValue = cursor.getInt(0);
            String phone = cursor.getString(1);
            double goal = cursor.getDouble(2);

            smsEnabled = (enabledValue == 1);

            // Fil inputs if saved
            if (phone != null) {
                phoneInput.setText(phone);
            }

            if (goal > 0) {
                goalWeightInput.setText(String.valueOf(goal));
            }
        }

        cursor.close();

        // Update status text and button state
        if (smsEnabled) {
            smsStatusText.setText("Status: Enabled");
            testSmsButton.setEnabled(true);
        }
        else {
            smsStatusText.setText("Status: Not Enabled");
            testSmsButton.setEnabled(false);
        }
    }

    // Handles enable button click logic
    private void handleEnableSmsClick() {

        // Get input text
        String phoneText = phoneInput.getText().toString().trim();
        String goalText = goalWeightInput.getText().toString().trim();

        // Validate phone
        if (phoneText.isEmpty()) {
            Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate goal weight
        if (goalText.isEmpty()) {
            Toast.makeText(this, "Enter a goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double goalWeightValue;

        // Convert goal weight to number
        try {
            goalWeightValue = Double.parseDouble(goalText);
        }
        catch (Exception e) {
            Toast.makeText(this, "Goal weight must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)  != PackageManager.PERMISSION_GRANTED) {

            // Request permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);

            // Save entered values anyway so user does not lose them
            dbHelper.saveSmsSettings(currentUserId, 0, phoneText, goalWeightValue);

            smsStatusText.setText("Status: Permission Not Granted");
            testSmsButton.setEnabled(false);
            return;
        }

        // Permission is granted, save as enabled
        dbHelper.saveSmsSettings(currentUserId, 1, phoneText, goalWeightValue);

        smsEnabled = true;
        smsStatusText.setText("Status: Enabled");
        testSmsButton.setEnabled(true);

        Toast.makeText(this, "SMS Alerts Enabled", Toast.LENGTH_SHORT).show();
    }

    // Send a text SMS message
    private void sendTestSms() {

        // Check enabled status
        if (!smsEnabled) {
            Toast.makeText(this, "Enable SMS alerts first", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get phone number
        String phoneText = phoneInput.getText().toString().trim();

        if (phoneText.isEmpty()) {
            Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send SMS
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneText, null, "Test SMS from Weight Tracker", null, null);

            Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
           Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show(); ;
        }
    }
}