package com.example.alicianicholson_weighttrackingmobileapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// WorkoutHistoryActivity displays workout history for the logged in user
public class WorkoutHistoryActivity extends AppCompatActivity {

    // Database helper instance
    private DatabaseHelper dbHelper;

    // Stores logged in user id
    private int currentUserId = -1;

    // Date input field
    private EditText workoutDateInput;

    // Exercise input field
    private EditText exerciseNameInput;

    // Duration input field
    private EditText workoutDurationInput;

    // Calories input field
    private EditText workoutCaloriesInput;

    // Add workout button
    private Button addWorkoutButton;

    // Back button
    private Button backToWeightHistoryButton;

    // Workout history table
    private TableLayout workoutTable;

    // Stores selected workout for updating
    private int selectedWorkoutId = -1;

    // Runs when activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge to edge display
        EdgeToEdge.enable(this);

        // Sets layout for workout history screen
        setContentView(R.layout.activity_workout_history);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user id from weight history activity
        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        // Connect workout date input
        workoutDateInput = findViewById(R.id.etWorkoutDate);

        // Connect exercise name input
        exerciseNameInput = findViewById(R.id.etExerciseName);

        // Connect workout duration input
        workoutDurationInput = findViewById(R.id.etWorkoutDuration);

        // Connect workout calories input
        workoutCaloriesInput = findViewById(R.id.etWorkoutCalories);

        // Connect add workout button
        addWorkoutButton = findViewById(R.id.btnAddWorkout);

        // Connect back button
        backToWeightHistoryButton = findViewById(R.id.btnBackToWeightHistory);

        // Connect workout table
        workoutTable = findViewById(R.id.tblWorkoutHistory);

        // Load workouts into table
        loadWorkouts();

        // Handles add or update workout button click
        addWorkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Checks if user is updating existing workout
                if (selectedWorkoutId == -1) {

                    // Add if no workout selected
                    addWorkout();
                }
                else {

                    // Update if workout selected
                    updateWorkout();
                }
            }
        });

        // Handles back button click
        backToWeightHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        // Handles system bar padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (view, insets) -> {

            // Gets system bar insets
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Applies padding to layout
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Loads workouts from SQLite and displays them in table
    private void loadWorkouts() {

        // Remove all rows except header row
        if (workoutTable.getChildCount() > 1) {
            workoutTable.removeViews(1, workoutTable.getChildCount() - 1);
        }

        // Check for missing user id
        if (currentUserId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get workouts for user
        Cursor cursor = dbHelper.getAllWorkoutsForUser(currentUserId);

        // Add row for each workout record
        while (cursor.moveToNext()) {

            // Read workout id
            int workoutId = cursor.getInt(0);

            // Read workout date
            String dateText = cursor.getString(1);

            // Read exercise name
            String exerciseText = cursor.getString(2);

            // Read workout duration
            int durationValue = cursor.getInt(3);

            // Read workout calories
            int caloriesValue = cursor.getInt(4);

            // Create table row
            TableRow row = new TableRow(this);

            // Handles row click for updating workout
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    // Stores selected workout id
                    selectedWorkoutId = workoutId;

                    // Fills input fields with selected workout data
                    workoutDateInput.setText(dateText);
                    exerciseNameInput.setText(exerciseText);
                    workoutDurationInput.setText(String.valueOf(durationValue));
                    workoutCaloriesInput.setText(String.valueOf(caloriesValue));

                    // Changes button text to indicate update mode
                    addWorkoutButton.setText("Update");
                }
            });

            // Create date text view
            TextView dateView = new TextView(this);
            dateView.setText(dateText);
            dateView.setPadding(8, 8, 8, 8);
            dateView.setTextSize(14);

            // Create exercise text view
            TextView exerciseView = new TextView(this);
            exerciseView.setText(exerciseText);
            exerciseView.setPadding(8, 8, 8, 8);
            exerciseView.setTextSize(14);

            // Create duration text view
            TextView durationView = new TextView(this);
            durationView.setText(String.valueOf(durationValue));
            durationView.setPadding(8, 8, 8, 8);
            durationView.setTextSize(14);

            // Create calories text view
            TextView caloriesView = new TextView(this);
            caloriesView.setText(String.valueOf(caloriesValue));
            caloriesView.setPadding(8, 8, 8, 8);
            caloriesView.setTextSize(14);

            // Create delete button
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTextSize(12);

            // Theme the delete button to match app primary color
            deleteButton.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.primary));
            deleteButton.setTextColor(ContextCompat.getColor(this, R.color.white));

            // Handles delete workout button click
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    deleteWorkout(workoutId);
                }
            });

            // Add views to row
            row.addView(dateView);
            row.addView(exerciseView);
            row.addView(durationView);
            row.addView(caloriesView);
            row.addView(deleteButton);

            // Add row to table
            workoutTable.addView(row);
        }

        // Close cursor
        cursor.close();
    }

    // Adds a workout entry to SQLite
    private void addWorkout() {

        // Get workout date text
        String dateText = workoutDateInput.getText().toString().trim();

        // Get exercise name text
        String exerciseText = exerciseNameInput.getText().toString().trim();

        // Get workout duration text
        String durationText = workoutDurationInput.getText().toString().trim();

        // Get workout calories text
        String caloriesText = workoutCaloriesInput.getText().toString().trim();

        // Check for empty fields
        if (dateText.isEmpty() || exerciseText.isEmpty() || durationText.isEmpty() || caloriesText.isEmpty()) {
            Toast.makeText(this, "Enter all workout details", Toast.LENGTH_SHORT).show();
            return;
        }

        int durationValue;
        int caloriesValue;

        // Convert duration and calories to numbers
        try {
            durationValue = Integer.parseInt(durationText);
            caloriesValue = Integer.parseInt(caloriesText);
        } catch (Exception e) {
            Toast.makeText(this, "Minutes and calories must be numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert workout into database
        long result = dbHelper.addWorkout(currentUserId, dateText, exerciseText, durationValue, caloriesValue);

        // Check insert result
        if (result == -1) {
            Toast.makeText(this, "Add failed", Toast.LENGTH_SHORT).show();
            return;
        }

        // Clear input fields
        clearWorkoutInputs();

        // Confirm workout was added
        Toast.makeText(this, "Workout added", Toast.LENGTH_SHORT).show();

        // Refresh table
        loadWorkouts();
    }

    // Updates workout entry in SQLite database
    private void updateWorkout() {

        // Get workout date text
        String dateText = workoutDateInput.getText().toString().trim();

        // Get exercise name text
        String exerciseText = exerciseNameInput.getText().toString().trim();

        // Get workout duration text
        String durationText = workoutDurationInput.getText().toString().trim();

        // Get workout calories text
        String caloriesText = workoutCaloriesInput.getText().toString().trim();

        // Check for empty fields
        if (dateText.isEmpty() || exerciseText.isEmpty() || durationText.isEmpty() || caloriesText.isEmpty()) {
            Toast.makeText(this, "Enter all workout details", Toast.LENGTH_SHORT).show();
            return;
        }

        int durationValue;
        int caloriesValue;

        // Convert duration and calories to numbers
        try {
            durationValue = Integer.parseInt(durationText);
            caloriesValue = Integer.parseInt(caloriesText);
        } catch (Exception e) {
            Toast.makeText(this, "Minutes and calories must be numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update workout in database
        int result = dbHelper.updateWorkout(selectedWorkoutId, dateText, exerciseText, durationValue, caloriesValue);

        // Check update result
        if (result == 0) {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            return;
        }

        // Reset selected workout id
        selectedWorkoutId = -1;

        // Reset button text back to add mode
        addWorkoutButton.setText("Add Workout");

        // Clear input fields
        clearWorkoutInputs();

        // Confirm workout was updated
        Toast.makeText(this, "Workout updated", Toast.LENGTH_SHORT).show();

        // Refresh table
        loadWorkouts();
    }

    // Deletes workout entry from SQLite
    private void deleteWorkout(int workoutId) {

        // Delete workout from database
        int result = dbHelper.deleteWorkout(workoutId);

        // Check delete result
        if (result == 0) {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            return;
        }

        // Confirm workout was deleted
        Toast.makeText(this, "Workout deleted", Toast.LENGTH_SHORT).show();

        // Refresh table
        loadWorkouts();
    }

    // Clears workout input fields
    private void clearWorkoutInputs() {

        // Clear date input
        workoutDateInput.setText("");

        // Clear exercise input
        exerciseNameInput.setText("");

        // Clear duration input
        workoutDurationInput.setText("");

        // Clear calories input
        workoutCaloriesInput.setText("");
    }
}