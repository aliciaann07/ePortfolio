package com.example.alicianicholson_weighttrackingmobileapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

// WeightHistoryActivity displays weight history for the logged in user
public class WeightHistoryActivity extends AppCompatActivity {

    // Database helper instance
    private DatabaseHelper dbHelper;

    // Stores logged in user id
    private int currentUserId = -1;

    // Weight history table
    private TableLayout weightTable;

    // Date input field
    private EditText dateInput;

    // Weight input field
    private EditText weightInput;

    // Add button
    private Button addButton;

    // SMS settings button
    private Button smsSettingsButton;

    // Workout history button
    private Button workoutHistoryButton;

    // Stores selected weight for updating
    private int selectedWeightId = -1;

    // Runs when activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge to edge display
        EdgeToEdge.enable(this);

        // Sets layout for weight history screen
        setContentView(R.layout.activity_weight_history);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user id from login activity
        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        // Connect table layout
        weightTable = findViewById(R.id.tblWeightHistory);

        // Connect date input
        dateInput = findViewById(R.id.etAddDate);

        // Connect weight input
        weightInput = findViewById(R.id.etWeight);

        // Connect add button
        addButton = findViewById(R.id.btnAdd);

        // Connect SMS settings button
        smsSettingsButton = findViewById(R.id.btnSmsSettings);

        // Connect workout history button
        workoutHistoryButton = findViewById(R.id.btnWorkoutHistory);

        // Load weight into table
        loadWeights();

        // Handles add or update button click
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Checks if user is updating existing weight
                if (selectedWeightId == -1) {

                    // Add if no weight selected
                    addWeight();
                }
                else {
                    // Update if weight selected
                    updateWeight();
                }
            }
        });

        // Handles SMS settings button click
        smsSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Create intent for SMS settings screen
                Intent intent = new Intent(WeightHistoryActivity.this, SmsNotificationsActivity.class);

                // Pass user id to SMS settings screen
                intent.putExtra("USER_ID", currentUserId);

                // Opens SMS settings screen
                startActivity(intent);
            }
        });

        // Handles workout history button click
        workoutHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Create intent for workout history screen
                Intent intent = new Intent(WeightHistoryActivity.this, WorkoutHistoryActivity.class);

                // Pass user id to workout history screen
                intent.putExtra("USER_ID", currentUserId);

                // Opens workout history screen
                startActivity(intent);
            }
        });

        // Handles system bar padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            // Gets system bar insets
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Applies padding to layout
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Loads weights from SQLite and displays them in table
    private void loadWeights() {

        // Remove all rows except header row
        if (weightTable.getChildCount() > 1) {
            weightTable.removeViews(1, weightTable.getChildCount() -1);
        }

        // Check for missing user id
        if (currentUserId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get weights for user
        Cursor cursor = dbHelper.getAllWeightsForUser(currentUserId);

        // Add row for each weight record
        while (cursor.moveToNext()) {

            // Read weight id
            int weightId = cursor.getInt(0);

            // Read date text
            String dateText = cursor.getString(1);

            // Read weight value
            String weightValue = String.valueOf(cursor.getDouble(2));

            // Create table row
            TableRow row = new TableRow(this);

            // Handles row click for updating weight
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // Stores selected weight id
                    selectedWeightId = weightId;

                    // Fills input fields with selected weight data
                    dateInput.setText(dateText);
                    weightInput.setText(String.valueOf(weightValue));

                    // Changes button text to indicate update mode
                    addButton.setText("Update");
                }
            });

            // Create date text view
            TextView dateView = new TextView(this);
            dateView.setText(dateText);
            dateView.setPadding(10,5,10,5);
            dateView.setTextSize(18);

            // Create weight text view
            TextView weightView = new TextView(this);
            weightView.setText(weightValue);
            weightView.setPadding(10, 5, 10, 5);
            weightView.setTextSize(18);

            // Create delete button
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTextSize(12);

            // Theme the delete button to match app primary color
            deleteButton.setBackgroundTintList(androidx.core.content.ContextCompat.getColorStateList(this, R.color.primary));
            deleteButton.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.white));

            // Handles delete button click
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteWeight(weightId);
                }
            });

            // Add views to row
            row.addView(dateView);
            row.addView(weightView);
            row.addView(deleteButton);

            // Add row to table
            weightTable.addView(row);
        }

        // Close cursor
        cursor.close();
    }

    // Adds a weight entry to SQLite
    private void addWeight() {

        // Get date text
        String dateText = dateInput.getText().toString().trim();

        // Get weight text
        String weightText = weightInput.getText().toString().trim();

        // Check for empty fields
        if (dateText.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double weightValue;

        // Convert weight to number
        try {
            weightValue = Double.parseDouble(weightText);
        } catch (Exception e) {
            Toast.makeText(this, "Weight must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert weight into database
        long result = dbHelper.addWeight(currentUserId, dateText, weightValue);

        // Check insert results
        if (result == -1) {
            Toast.makeText(this, "Add failed", Toast.LENGTH_SHORT).show();
            return;
        }

        // Clear input fields
        dateInput.setText("");
        weightInput.setText("");

        Toast.makeText(this, "Weight added", Toast.LENGTH_SHORT).show();

        // Refresh table
        loadWeights();
    }

    // Updates weight entry in SQLite database
    private void updateWeight() {

        // Get date text
        String dateText = dateInput.getText().toString().trim();

        // Get weight text
        String weightText = weightInput.getText().toString().trim();

        // Check for empty fields
        if (dateText.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double weightValue;

        // Convert weight to number
        try {
            weightValue = Double.parseDouble(weightText);
        } catch (Exception e) {
            Toast.makeText(this, "Weight must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Updates weight in database
        int result = dbHelper.updateWeight(selectedWeightId, dateText, weightValue);

        // Check update result
        if (result == 0) {
            Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show();

        // Resets selected weight id
        selectedWeightId = -1;

        // Resets button text back to add mode
        addButton.setText("Add");

        // Clear input fields
        dateInput.setText("");
        weightInput.setText("");

        // Reload updated weight history table
        loadWeights();
    }

    // Deletes weight entry from SQLite
    private void deleteWeight(int weightId) {

        // Delete weight from database
        int result = dbHelper.deleteWeight(weightId);

        // Check delete result
        if (result == 0) {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Weight deleted", Toast.LENGTH_SHORT).show();

        // Refresh table
        loadWeights();
    }
}