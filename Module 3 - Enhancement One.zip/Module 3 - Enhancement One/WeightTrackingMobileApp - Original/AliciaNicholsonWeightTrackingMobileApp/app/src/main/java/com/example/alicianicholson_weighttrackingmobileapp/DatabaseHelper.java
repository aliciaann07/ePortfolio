package com.example.alicianicholson_weighttrackingmobileapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



// Database Helper manages database creation and CRUD operations
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name
    private static final String DB_NAME = "weight_tracker.db";

    // Database version
    private static final int DB_VERSION = 1;

    // Users table name
    public static final String TABLE_USERS = "users";

    // Users table columns
    public static final String COL_USER_ID = "user_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Weights table name
    public static final String TABLE_WEIGHTS = "weights";

    // Weights table columns
    public static final String COL_WEIGHT_ID = "weight_id";
    public static final String COL_WEIGHT_USER_ID = "user_id";
    public static final String COL_WEIGHT_DATE = "date_text";
    public static final String COL_WEIGHT_VALUE = "weight_value";

    // Settings table name
    public static final String TABLE_SETTINGS = "settings";

    // Settings table columns
    public static final String COL_SETTING_ID = "setting_id";
    public static final String COL_SETTING_USER_ID = "user_id";
    public static final String COL_SMS_ENABLED = "sms_enabled";
    public static final String COL_PHONE_NUMBER = "phone_number";
    public static final String COL_GOAL_WEIGHT = "goal_weight";

    // Constructor creates database helper
    public DatabaseHelper (Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Creates database tables when database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD + " TEXT NOT NULL" + ")";

        db.execSQL(createUsers);

        // Create weights table
        String createWeights = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT_USER_ID + " INTEGER NOT NULL, " +
                COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                COL_WEIGHT_VALUE + " REAL NOT NULL, " +
                "FOREIGN KEY(" + COL_WEIGHT_USER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + COL_USER_ID + ")" + ")";

        db.execSQL(createWeights);

        // Create settings table
        String createSettings = "CREATE TABLE " + TABLE_SETTINGS + " (" +
                COL_SETTING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SETTING_USER_ID + " INTEGER UNIQUE NOT NULL, " +
                COL_SMS_ENABLED + " INTEGER DEFAULT 0, " +
                COL_PHONE_NUMBER + " TEXT, " +
                COL_GOAL_WEIGHT + " REAL, " +
                "FOREIGN KEY(" + COL_SETTING_USER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + COL_USER_ID + ")" + ")";

        db.execSQL(createSettings);
    }

    // Recreates database if version is upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Drop settings table
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);

        // Drop weights table
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);

        // Drop users table
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        // Recreate tables
        onCreate(db);
    }

    // Creates new user account
    public long createUser(String username, String password) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Create values object
        ContentValues values = new ContentValues();

        // Store username and password
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        // Insert user into table
        return db.insert(TABLE_USERS, null, values);
    }

    // Checks login and returns user id
    public int getUserId(String username, String password) {

        // Get readable database
        SQLiteDatabase db = getReadableDatabase();

        // SQL query to find user
        String sql = "SELECT " + COL_USER_ID +
                " FROM " + TABLE_USERS +
                " WHERE " + COL_USERNAME + "=? AND " +
                COL_PASSWORD + "=?";

        // Execute query
        Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        int userId = -1;

        // Checks if user exists
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        // Close cursor
        cursor.close();

        return userId;
    }

    // Checks if username already exists
    public boolean usernameExists(String username) {

        // Get readable database
        SQLiteDatabase db = getReadableDatabase();

        // SQL query to check username
        String sql = "SELECT 1 FROM " + TABLE_USERS +
                " WHERE " + COL_USERNAME + "=?";

        // Execute query
        Cursor cursor = db.rawQuery(sql, new String[]{username});

        boolean exists = cursor.moveToFirst();

        // Close cursor
        cursor.close();

        return exists;
    }

    // Adds a weight entry
    public long addWeight(int userId, String dateText, double weightValue) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Create values object
        ContentValues values = new ContentValues();

        // Store weight data
        values.put(COL_WEIGHT_USER_ID, userId);
        values.put(COL_WEIGHT_DATE, dateText);
        values.put(COL_WEIGHT_VALUE, weightValue);

        // Insert weight into table
        return db.insert(TABLE_WEIGHTS, null, values);
    }

    // Gets all weights for a user
    public Cursor getAllWeightsForUser(int userId) {

        // Get readable database
        SQLiteDatabase db = getReadableDatabase();

        // SQL query to get weights
        String sql = "SELECT " + COL_WEIGHT_ID + ", " +
                COL_WEIGHT_DATE + ", " +
                COL_WEIGHT_VALUE +
                " FROM " + TABLE_WEIGHTS +
                " WHERE " + COL_WEIGHT_USER_ID + "=?" +
                " ORDER BY " + COL_WEIGHT_ID + " DESC";

        return db.rawQuery(sql, new String[]{String.valueOf(userId)});
    }

    // Updates a weight entry
    public int updateWeight(int weightId, String dateText, double weightValue) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Create values object
        ContentValues values = new ContentValues();

        // Update weight data
        values.put(COL_WEIGHT_DATE, dateText);
        values.put(COL_WEIGHT_VALUE, weightValue);

        // Update row in table
        return db.update(TABLE_WEIGHTS, values,
                COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(weightId)});
    }

    // Deletes a weight entry
    public int deleteWeight(int weightId) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Delete weight from table
        return db.delete(TABLE_WEIGHTS,
                COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(weightId)});
    }

    // Gets SMS Settings for a user
    public Cursor getSmsSettings(int userId) {

        // Get readable database
        SQLiteDatabase db = getReadableDatabase();

        // SQL query to get settings row
        String sql = "SELECT " + COL_SMS_ENABLED + ", " +
                    COL_PHONE_NUMBER + ", " +
                    COL_GOAL_WEIGHT +
                    " FROM " + TABLE_SETTINGS +
                    " WHERE " + COL_SETTING_USER_ID + "=?";

        return db.rawQuery(sql, new String[]{String.valueOf(userId)});
    }

    // Saves or updates SMS settings for a user
    public void saveSmsSettings(int userId, int smsEnabled, String phoneNumber, double goalWeight) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Create values object
        ContentValues values = new ContentValues();

        // Store settings data
        values.put(COL_SETTING_USER_ID, userId);
        values.put(COL_SMS_ENABLED, smsEnabled);
        values.put(COL_PHONE_NUMBER, phoneNumber);
        values.put(COL_GOAL_WEIGHT, goalWeight);

        // Try to update first
        int rowsUpdated = db.update(TABLE_SETTINGS,
                values,
                COL_SETTING_USER_ID + "=?",
                new String[]{String.valueOf(userId)});

        // If no row was updated, insert new row
        if (rowsUpdated == 0) {
            db.insert(TABLE_SETTINGS, null, values);
        }
    }

    // Gets settings for a user
    public Cursor getSettingsForUser(int userId) {

        // Get readable database
        SQLiteDatabase db = getReadableDatabase();

        // SQL query to get settings
        String sql = "SELECT " + COL_SMS_ENABLED + ", " +
                COL_PHONE_NUMBER + ", " +
                COL_GOAL_WEIGHT +
                " FROM " + TABLE_SETTINGS +
                " WHERE " + COL_SETTING_USER_ID + "=?";

        return db.rawQuery(sql, new String[]{String.valueOf(userId)});
    }

    // Creates default settings row if one does not exist
    public long createDefaultSettings(int userId) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Create values object
        ContentValues values = new ContentValues();

        // Default values
        values.put(COL_SETTING_USER_ID, userId);
        values.put(COL_SMS_ENABLED, 0);
        values.put(COL_PHONE_NUMBER, "");
        values.put(COL_GOAL_WEIGHT, 0.0);

        // Insert settings into table
        return db.insert(TABLE_SETTINGS, null, values);
    }

    // Updates settings for a user
    public int updateSettings(int userId, int smsEnabled, String phoneNumber, double goalWeight) {

        // Get writeable database
        SQLiteDatabase db = getWritableDatabase();

        // Create values object
        ContentValues values = new ContentValues();

        // Store updated values
        values.put(COL_SMS_ENABLED, smsEnabled);
        values.put(COL_PHONE_NUMBER, phoneNumber);
        values.put(COL_GOAL_WEIGHT, goalWeight);

        // Update row in table
        return db.update(TABLE_SETTINGS, values,
                COL_SETTING_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
    }
}
